<?php
error_reporting(0);
include 'cnx.php';
$sql = "INSERT INTO destinos (id, correo, nombre) " +
  "VALUES ('NULL', '$correo', '$nombre')";
$result = mysql_query($sql);
echo "¡Gracias! Hemos recibido sus datos.\n";
?>