<?php
	$host='127.0.0.1';
	$user='u509644246_tt';
	$password='12345678';
	
	$connection = mysql_connect($host,$user,$password);
	
	if(!$connection){
		die('Connection Failed');
	}
	else{
		$dbconnect = @mysql_select_db('u509644246_tembl', $connection);
		
		if(!$dbconnect){
			die('Could not connect to Database');
		}
		else{
			$query = 'SELECT * FROM destinos';
			$resultset = mysql_query($query, $connection);
			
			$records= array();
			
			while($r = mysql_fetch_assoc($resultset)){
				$records[] = $r;
			}
			
			echo json_encode($records);
		}
	}
?>