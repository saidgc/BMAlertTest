<?php

    // Especificar correctamente el path al archivo class.phpmailer.php
    require_once ('class.phpmailer.php');
    require_once('class.smtp.php');
    error_reporting(0);
$host="127.0.0.1";
$user="u509644246_tt";
$pass="12345678";
$db="u509644246_tembl";
$con=mysql_connect($host,$user,$pass)or die(mysql_error());
mysql_select_db($db)or die("error en la base de datos");


$con=mysql_query("select * from temblor1");
$r=mysql_fetch_array($con)or die(mysql_error());
$luga=$r['lugar'];
echo $luga;

$result=mysql_query("select * from destinos")or die(mysql_error());
while($row=mysql_fetch_array($result)){

$coreo=$row['correo'];
$lugar=$luga;
    $mail= new PHPMailer();

    $body             = "Un sismo ha sido detectado en $lugar"; // Cuerpo del mensaje
    $mail->IsSMTP(); // Usar SMTP para enviar
    $mail->SMTPDebug  = 0; // habilita información de depuración SMTP (para pruebas)
                           // 1 = errores y mensajes
                           // 2 = sólo mensajes
    $mail->SMTPAuth   = true; // habilitar autenticación SMTP
    $mail->Host       = "smtp.gmail.com"; // establece el servidor SMTP
    $mail->Port       = 587; // configura el puerto SMTP utilizado
    $mail->SMTPSecure = "tls";
    $mail->Username   = "hackbytemex@gmail.com"; // nombre de usuario UGR
    $mail->Password   = "bytemexcontacto"; // contraseña del usuario UGR
 
    $mail->FromName="hackbytemex@gmail.com";
    $mail->Subject    = "Asunto del mensaje";
    $mail->MsgHTML($body); // Fija el cuerpo del mensaje

    $address = $coreo; // Dirección del destinatario
    $mail->AddAddress($address, "Nombre del destinatario");

    if(!$mail->Send()) {
        echo "Error: " . $mail->ErrorInfo;
    }
    else {
        echo "¡Mensaje enviado!";
    }
}
?>


