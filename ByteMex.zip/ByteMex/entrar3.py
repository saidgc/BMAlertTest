# -*- coding: utf-8 -*-
__author__ = 'Byte Mex'

from bs4 import BeautifulSoup
import requests
import time
import urllib2
import urllib
#def ejecutaScript():


print ("hola")
url = "http://www.ssn.unam.mx/"
#def ejecutaScript():
while (1):
# Realizamos la petición a la web
	req = requests.get(url)

# Comprobamos que la petición nos devuelve un Status Code = 200
	statusCode = req.status_code
	if statusCode == 200:

    # Pasamos el contenido HTML de la web a un objeto BeautifulSoup()
    			html = BeautifulSoup(req.text)

    # Obtenemos todos los divs donde estan las entradas
    			entradas = html.find_all('div',{'class':'ultimoE'})

    
    			for i,entrada in enumerate(entradas):
       
        			titulo = entrada.find('div', {'class' : 'ultimoE1der'}).getText()
        
        			lugar = entrada.find('div', {'id' : 'localizacion'}).getText()

        
        			print (titulo)
        			print (lugar)
        			
        			params = urllib.urlencode({"t": titulo, "l": lugar})  
        			#params2 = urllib.urlencode({"en": "1"})  
        			f = urllib2.urlopen("http://bytemex.esy.es/temblor.php" + "?" + params)  
        			#f2 = urllib2.urlopen("http://bytemex.esy.es/enviacorreo.php" + "?" + params2) 
        			time.sleep(5) 
       
	else:
    			print "Status Code %d" %statusCode






