<?php
error_reporting(0);
$host="127.0.0.1";
$user="u509644246_tt";
$pass="12345678";
$db="u509644246_tembl";
$con=mysql_connect($host,$user,$pass)or die(mysql_error());
mysql_select_db($db)or die("error en la base de datos");

?>