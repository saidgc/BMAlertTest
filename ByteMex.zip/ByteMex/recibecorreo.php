<head>

</head>
<?php

	header('location:correo/correo.php');




?>