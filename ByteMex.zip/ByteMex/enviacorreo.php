

<?php
error_reporting(0);
include 'cnx.php';
$si=$_GET['en'];

if ($si==1){
header('location:recibecorreo.php');

}else{


}

?>