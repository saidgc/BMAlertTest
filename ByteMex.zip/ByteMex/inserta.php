<?php
error_reporting(0);
	$host='127.0.0.1';
	$user='u509644246_tt';
	$password='12345678';
	
	$connection = mysql_connect($host,$user,$password);
	
	$username = $_GET['a'];
	
	$info = $_GET['c'];

	
	if(!$connection){
		die('Connection Failed');
	}
	else{
		$dbconnect = mysql_select_db('u509644246_tembl');
		
		if(!$dbconnect){
			die('Could not connect to Database');
		}
		else{
			$query = "INSERT INTO destinos VALUES (null,$username,$info);";
			mysql_query($query, $connection) or die(mysql_error());
			
			echo 'Successfully added.';
			echo $query;
		}
	}
?>