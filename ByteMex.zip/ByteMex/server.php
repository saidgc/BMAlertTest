<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Servicio Sismol&oacute;gico Nacional</title>

<link rel="shortcut icon" href="/favicon.ico" />
<style type="text/css">

	BODY { color:#333366;}
        H1 { color:#333366; font-size: 16pt; text-align: center;}
        A:link { color:#FFFFFF;}
        A:visited { color:#FFFFFF;}
        A:hover { color:#FFFFFF;}

	A.clase0:link { color:#333366; text-decoration: none;}
	A.clase0:visited { color:#333366; text-decoration: none;}
	A.clase0:hover { color:#9999FF; text-decoration: none;}

        A.clase1:link { color:red;}
        A.clase1:visited { color:red;}
        A.clase1:hover { color:red;}

        A.clase2:link { color:#CCCC33;}
        A.clase2:visited { color:#CCCC33;}
        A.clase2:hover { color:#CCCC33;}

	A.clase3:link { color:#999900;}
	A.clase3:visited { color:#9999FF;}
	A.clase3:hover { color:#CCCC33;}

	A.clase4:link { color:#FFFFFF; text-decoration: none;}
	A.clase4:visited { color:#FFFFFF; text-decoration: none;}
	A.clase4:hover { color:#FFFFFF; text-decoration: none;}
</style>
<script language="JavaScript">
<!--
function mmLoadMenus() {
  if (window.mm_menu_1019185234_0) return;
  window.mm_menu_1019185234_0 = new Menu("root",125,18,"Verdana, Arial, Helvetica, sans-serif",12,"#FFFFFF","#FFFFFF","#333366","#C3B636","left","middle",3,0,1000,-5,7,true,true,true,0,true,true);
  mm_menu_1019185234_0.addMenuItem("&Uacute;ltimos&nbsp;sismos","window.open('ultimos.html', '_self');");
  mm_menu_1019185234_0.addMenuItem("Reporte&nbsp;semanal","window.open('http://www2.ssn.unam.mx/website/jsp/semanal.jsp', '_self');");
  mm_menu_1019185234_0.addMenuItem("Sismogramas","window.open('http://www2.ssn.unam.mx/website/jsp/sismogramas-info.jsp', '_self');");
   mm_menu_1019185234_0.hideOnMouseOut=true;
   mm_menu_1019185234_0.bgColor='#555555';
   mm_menu_1019185234_0.menuBorder=1;
   mm_menu_1019185234_0.menuLiteBgColor='#FFFFFF';
   mm_menu_1019185234_0.menuBorderBgColor='#777777';

  window.mm_menu_1019185649_0 = new Menu("root",150,18,"Verdana, Arial, Helvetica, sans-serif",12,"#FFFFFF","#FFFFFF","#333366","#C3B636","left","middle",3,0,1000,-5,7,true,true,true,0,true,true);
  mm_menu_1019185649_0.addMenuItem("Sismos&nbsp;fuertes","window.open('http://www2.ssn.unam.mx/website/jsp/fuertes.jsp', '_self');");
  mm_menu_1019185649_0.addMenuItem("Cat&aacute;logo","window.open('http://www2.ssn.unam.mx/website/jsp/catalogo1.jsp', '_self');");
  mm_menu_1019185649_0.addMenuItem("Mapas&nbsp;de&nbsp;Intensidades","window.open('/shakeMap.html', '_self');");
   mm_menu_1019185649_0.hideOnMouseOut=true;
   mm_menu_1019185649_0.bgColor='#555555';
   mm_menu_1019185649_0.menuBorder=1;
   mm_menu_1019185649_0.menuLiteBgColor='#FFFFFF';
   mm_menu_1019185649_0.menuBorderBgColor='#777777';

  window.mm_menu_1019185801_0 = new Menu("root",149,18,"Verdana, Arial, Helvetica, sans-serif",12,"#FFFFFF","#FFFFFF","#333366","#C3B636","left","middle",3,0,1000,-5,7,true,true,true,0,true,true);
  mm_menu_1019185801_0.addMenuItem("Boletines&nbsp;mensuales","window.open('http://www2.ssn.unam.mx/website/jsp/boletines.jsp', '_self');");
  mm_menu_1019185801_0.addMenuItem("Estad&iacute;sticas","window.open('http://www2.ssn.unam.mx/website/jsp/estadisticas.jsp', '_self');");
  //mm_menu_1019185801_0.addMenuItem("Mapas&nbsp;de&nbsp;intensidad","window.open('http://www2.ssn.unam.mx/website/jsp/intensidad.jsp', '_self');");
  mm_menu_1019185801_0.addMenuItem("Reportes&nbsp;s&iacute;smicos","window.open('http://www2.ssn.unam.mx/website/jsp/reportes.jsp', '_self');");
   mm_menu_1019185801_0.hideOnMouseOut=true;
   mm_menu_1019185801_0.bgColor='#555555';
   mm_menu_1019185801_0.menuBorder=1;
   mm_menu_1019185801_0.menuLiteBgColor='#FFFFFF';
   mm_menu_1019185801_0.menuBorderBgColor='#777777';

   window.mm_menu_0514195845_0 = new Menu("root",150,20,"Verdana, Arial, Helvetica, sans-serif",12,"#0000cc","#000099","#ffcc00","#0099ff","left","middle",3,0,1000,-5,7,true,true,true,0,true,true);
   mm_menu_0514195845_0.addMenuItem("sopa&nbsp;de&nbsp;letras","location='sopaletras.jsp'");
   mm_menu_0514195845_0.addMenuItem("crucigrama","location='crucigrama.jsp'");
   mm_menu_0514195845_0.addMenuItem("ilumina","location='ilumina.jsp'");
   mm_menu_0514195845_0.addMenuItem("serpientes&nbsp;y&nbsp;escaleras","location='serpientes.jsp'");
   mm_menu_0514195845_0.hideOnMouseOut=true;
   mm_menu_0514195845_0.menuBorder=1;
   mm_menu_0514195845_0.menuLiteBgColor='#ffffff';
   mm_menu_0514195845_0.menuBorderBgColor='#9900ff';
   mm_menu_0514195845_0.bgColor='#555555';

  window.mm_menu_1019190134_0 = new Menu("root",194,18,"Verdana, Arial, Helvetica, sans-serif",12,"#FFFFFF","#FFFFFF","#333366","#C3B636","left","middle",3,0,1000,-5,7,true,true,true,0,true,true);
  mm_menu_1019190134_0.addMenuItem("Visitas&nbsp;guiadas","window.open('http://www2.ssn.unam.mx/website/jsp/visitas.jsp', '_self');");
  mm_menu_1019190134_0.addMenuItem("Preguntas&nbsp;frecuentes&nbsp;(FAQ)","window.open('http://www2.ssn.unam.mx/website/jsp/faq.jsp', '_self');");
  mm_menu_1019190134_0.addMenuItem("&iquest;Qu&eacute;&nbsp;hacer&nbsp;ante&nbsp;un&nbsp;sismo?","window.open('http://www2.ssn.unam.mx/website/jsp/que_hacer.jsp', '_self');");
  mm_menu_1019190134_0.addMenuItem("Predicci&oacute;n&nbsp;s&iacute;smica","window.open('http://www2.ssn.unam.mx/website/jsp/prediccion.jsp', '_self');");
  mm_menu_1019190134_0.addMenuItem("Temas&nbsp;de&nbsp;sismolog&iacute;a","window.open('http://www2.ssn.unam.mx/website/jsp/sismologia.jsp', '_self');");
  mm_menu_1019190134_0.addMenuItem("Podcast SSN","window.open('http:///www2.ssn.unam.mx:8080/podcast/podcast.jsp', '_self');");
  mm_menu_1019190134_0.addMenuItem("Carteles","window.open('http://www2.ssn.unam.mx/website/jsp/carteles.jsp', '_self');");
  mm_menu_1019190134_0.addMenuItem("Otros&nbsp;documentos","window.open('http://www2.ssn.unam.mx/website/jsp/otros.jsp', '_self');");
   mm_menu_1019190134_0.hideOnMouseOut=true;
   mm_menu_1019190134_0.bgColor='#555555';
   mm_menu_1019190134_0.menuBorder=1;
   mm_menu_1019190134_0.menuLiteBgColor='#FFFFFF';
   mm_menu_1019190134_0.menuBorderBgColor='#777777';

mm_menu_1019190134_0.writeMenus();
} // mmLoadMenus()
//-->
</script>
<script language="JavaScript" src="/jsp/mm_menu.js"></script>



<link href="estilos/general.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false&amp;language=es"></script>
<script type="text/javascript">
        window.onload = function(){
         var n=1;
         var options = {
                         zoom: 4
                         , center: new google.maps.LatLng(23.5, -104)
                         , mapTypeId: google.maps.MapTypeId.HYBRID
                       };
         var map = new google.maps.Map(document.getElementById('map'), options);

         //var place = new Array();
        // place['1'] = new google.maps.LatLng(13.56, -92.28);
         var place = new google.maps.LatLng(13.56, -92.28);
         //place['Ciudad Altamirano Guerrero'] = new google.maps.LatLng(18.2, -101.01);
         
         var marker = new google.maps.Marker({
                         position: place
                         , map: map                         
                         , icon: '/markers/green/blank.png'
            });
         
         google.maps.event.addListener(marker, 'click', function(){
         		 var popup = new google.maps.InfoWindow({
         		 content: 'Fecha:2016-04-15<br>Hora:09:11:25<br>Latitud:13.56<br>Longitud:-92.28<br>Magnitud:6.1<br>Prf:12.0<br>124 km al SUR de  CD HIDALGO, CHIS        '         		 
         		 }); 
            		 popup.open(map, marker);
         })
         		 
         
         
 
       /* for(var i in place){
            var marker = new google.maps.Marker({
                         position: place[i]
                         , map: map
                         , title: i 
                         , icon: 'http://gmaps-samples.googlecode.com/svn/trunk/markers/red/marker' + n++ + '.png'
            });
        };

        google.maps.event.addListener(marker, 'click', function(){
            var popup = new google.maps.InfoWindow();
            var note = 'Fecha:2016-04-15<br>Hora:09:11:25<br>Latitud:13.56<br>Longitud:-92.28<br>Magnitud:6.1<br>Prf:12.0<br>124 km al SUR de  CD HIDALGO, CHIS        ';
               // nore = note + 'HORA:			09:11:25';
                
            popup.setContent(note);
            popup.open(map, marker);
             })*/
        }
</script>

</head>


<body>
<script language="JavaScript1.2">mmLoadMenus();</script>
<div align="center"></div>
<table width="1021" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr> 
  <td height="27" colspan="4" background="/imagenes/index_supizq.jpg">
  <a type="application/rss+xml" href="jsp/ultimos_sismosT.xml" TARGET="_TOP"><img src="/imagenes/rss.gif" alt="RSS - &uacute;ltimos sismos registrados" align="middle" border="0" hspace=4></a> &nbsp;&nbsp;<a href="http://www2.ssn.unam.mx/website/jsp/sismotel.jsp"><img src="/img/telmi.gif" alt="Tel&eacute;fonos" align="middle" border="0" hspace=4></a>
  </td>
  <td height="27" colspan="14" align="center" valign="middle" background="/imagenes/index_supizq.jpg">
  	<table width=100%>
		<tr>
			<td width=15% align="center"><a href="index.html" class=clase4><font color=#FFFFFF size=-1><b>INICIO</b></font></a></td>
			<td width=1 bgcolor=#FFFFFF></td>
			<td width=25% align="center"><a href="http://www2.ssn.unam.mx/website/jsp/acerca_del_ssn.jsp" class=clase4><font color=#FFFFFF size=-1><b>ACERCA DEL SSN</b></font></a></td>
			<td width=1 bgcolor=#FFFFFF></td>
			<td width=20% align="center"><a href="http://www2.ssn.unam.mx/website/jsp/mapa-sitio.jsp" class=clase4><font color=#FFFFFF size=-1><b>MAPA DE SITIO</b></font></a></td>
			<td width=40% align="right"><img src="/imagenes/bandera-mexico.png" border=0 align="top"></td>
		</tr>
	</table>
  </td>
  </tr>
  <tr> 
    <td colspan="2" rowspan="2" align="center"><p title="p&aacute;gina de inicio del SSN"><a href="index.html"><img src="/imagenes/index_06_ssn.jpg" width="169" height="92" border="0"></a></p></td>
    <td colspan="11" rowspan="2" valign="top"><img src="/imagenes/index_07_onda.jpg" width="632" height="92"></td>
    <td height="54" colspan="2" valign="top"><p title="Universidad Nacional Aut&oacute;noma de M&eacute;xico"><a href="http://www.unam.mx" target="_blank"><img src="/imagenes/unam_logo2.gif" width="82" height="54" border="0"></a></p></td>
    <td colspan="3" valign="top"><p title="Instituto de Geof&iacute;sica"><a href="http://www.geofisica.unam.mx" target="_blank"><img src="/imagenes/index_09_geo.jpg" width="109" height="54" border="0"></a></p></td>
    <td></td>
  </tr>
  <tr> 
    <td height="38" colspan="5" valign="top"><img src="/imagenes/index_10.jpg" width="220" height="38"></td>
    <td></td>
  </tr>
  <tr> 
    <td height="14" colspan="18" align="center"><img src="/imagenes/index_11.jpg" width="1020" height="14"></td>
    <td></td>
  </tr>
  <tr> 
    <td width="158" rowspan="2" align="center"><p title="Acerca del SSN"><a href="http://www2.ssn.unam.mx/website/jsp/acerca_del_ssn.jsp"><img src="/imagenes/index_13_welc.png" width="158" height="65" border="0"></a></td>
    <p></p>
    <td colspan="15" align="center" valign="middle" bgcolor="#333366"> <a href="javascript:;" onMouseOver="MM_showMenu(window.mm_menu_1019185234_0,0,28,null,'image1')" onMouseOut="MM_startTimeout();"><img src="/imagenes/sismicidad_reciente.png" name="image1"  border="0" id="image1"></a>	
      <a href="javascript:;" onMouseOver="MM_showMenu(window.mm_menu_1019185649_0,0,28,null,'image2')" onMouseOut="MM_startTimeout();"><img src="/imagenes/sismicidad_historica.png" name="image2"  border="0" id="image2"></a> 
      <a href="javascript:;" onMouseOver="MM_showMenu(window.mm_menu_1019185801_0,0,28,null,'image3')" onMouseOut="MM_startTimeout();"><img src="/imagenes/divulgacion.png" name="image3"  border="0" id="image3"></a> 
      <a href="http://www2.ssn.unam.mx/website/jsp/brigada.jsp"><img src="/imagenes/ssn_ninos.png"  border="0"></a> <a href="javascript:;" onMouseOver="MM_showMenu(window.mm_menu_1019190134_0,0,28,null,'image4')" onMouseOut="MM_startTimeout();"><img src="/imagenes/informacion_general.png" name="image4"  border="0" id="image4"></a> 
      <a href="http://www2.ssn.unam.mx/website/jsp/ligas.jsp"><img src="/imagenes/sitios_de_interes.png"  border="0"></a> 
    <td colspan="2" valign="top"><img src="/imagenes/index_21.jpg" width="62" height="32"></td>
    <td></td>
  </tr>
  <tr> 
    <td colspan="16" rowspan="2" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" background="/imagenes/index_lineainf.jpg">
        <!--DWLayoutTable-->
        <tr> 
          <td width="807" height="33" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
        </tr>
      </table></td>
    <td width="55" rowspan="2" valign="top"><img src="/imagenes/index_23.jpg" width="55" height="34"></td>
    <td height="33"></td>
  </tr>
  <tr> 
    <td height="1" align="center"></td>
    <td></td>
  </tr>
  <tr> 
    <td height="1" align="center"></td>
    <td width="11"></td>
    <td width="89"></td>
    <td width="19"></td>
    <td width="80"></td>
    <td width="76"></td>
    <td width="24"></td>
    <td></td>
    <td width="20"></td>
    <td width="81"></td>
    <td width="95"></td>
    <td width="6"></td>
    <td width="42"></td>
    <td width="58"></td>
    <td width="53"></td>
    <td width="47"></td>
    <td width="7"></td>
    <td></td>
    <td></td>
  </tr>
</table>


<div id="marcoTabla">
	<div class="separador"></div>	
	<div id="sismo" class="ultimoE">
		<div class="ultimoE1">
		  <div class="ultimoE1izq">:: FECHA </div>
		  <div class="ultimoE1der">2016-04-15</div>		  
		</div>
		<div class="ultimoE1">
		  <div class="ultimoE1izq">:: HORA  </div>
		  <div class="ultimoE1der">09:11:25</div>
		</div>
		<div class="ultimoE1">
		  <div class="ultimoE1izq">:: LATITUD </div>
		  <div class="ultimoE1der">13.56</div>
		</div>
		<div class="ultimoE1">
		  <div class="ultimoE1izq">:: LONGITUD </div>
		  <div class="ultimoE1der">-92.28</div>
		</div>
		<div class="ultimoE1">
		  <div class="ultimoE1izq">:: PROFUNDIDAD </div>
		  <div class="ultimoE1der">12.0</div>
		</div>
		<div class="ultimoE1">
		  <div class="ultimoE1izq">:: MAGNITUD </div>
		  <div class="ultimoE1der">6.1</div>
		</div>
		<div class="ultimoE1">
		  <div class="ultimoE1izq">:: EPICENTRO </div>
		  <div class="ultimoE1der"></div>
		</div>
		<div id="localizacion">
		  124 km al SUR de  CD HIDALGO, CHIS        
		</div>	
	</div>
	<div class="clase_avisos">
	   <div id="marcomapa">
		<div id="map"></div>
	   </div>	   	   
	</div>
	
	<div class="anuncios">
	   <div class="contanun"><a href="http://www2.ssn.unam.mx/website/jsp/red_sismologica.jsp#Red de Banda"><img src="img/estaciones.gif" border="0"></a></div><div class="conttxt"><a href="http://www2.ssn.unam.mx/website/jsp/red_sismologica.html#Red de Banda">Estaciones sismol&oacute;gicas</a></div>	     
	</div>
			
	<div class="anuncios">
	   <div class="contanun"><a href="http://www2.ssn.unam.mx/website/jsp/RSVM/index.jsp"><img src="img/RSVM.gif" border="0"></div><div class="conttxt"><a href="http://www2.ssn.unam.mx/website/jsp/RSVM/index.jsp">Red del Valle de M&eacute;xico</a></div>	     
	</div>
	
	<div class="anuncios">
	   <div class="contanun"><a href="http://www2.ssn.unam.mx/website/jsp/tacana.jsp"><img src="img/volcan_tacanaN.gif" border="0"></div><div class="conttxt"><a href="http://www2.ssn.unam.mx/website/jsp/tacana.jsp">Red s&iacute;smica del Volc&aacute;n Tacan&aacute;</a></div>	     
	</div>
	
	<div class="anuncios">
	   <div class="contanun"><a href="http://www2.ssn.unam.mx/website/jsp/MapaZonasSismicasDF.gif"><img src="img/MapaZonasSismicasDF-N.gif" border="0"></a></div><div class="conttxt"><a href="http://www2.ssn.unam.mx/website/jsp/MapaZonasSismicasDF.gif">Zonas S&iacute;smicas Cd. de M&eacute;xico</a></div>	     
	</div>

        <div class="anuncios">
           <div class="contanun"><a href="http://www2.ssn.unam.mx/website/jsp/CTBTO.jsp"><img src="img/ctbtoN.jpg" border="0"></a></div><div class="conttxt"><a href="http
://www2.ssn.unam.mx/website/jsp/CTBTO.jsp">Relaci&oacute;n con el CTBTO</a></div>
        </div>

	<div class="anuncios">
	   <div class="contanun"><a href="http://www2.ssn.unam.mx/imagenes/sismicidad_2015.jpg" target="_blank"><br><img src="img/sismicidad_2015_icono.jpg" border="0"></a></div><div class="conttxt"><a href="http://www2.ssn.unam.mx/imagenes/sismicidad_2015.jpg" target="_blank">Sismicidad 2015</a></div>	     
	</div>

	
	<div class="anuncios">
	   <div class="contanun"></div>	     
	</div>
	
	<div id="titulo" class="clase_titulo">
	<Marquee><font size=+1>El Servicio Sismol&oacute;gico Nacional NO opera ninguna alerta s&iacute;smica.
</font></Marquee>
	</div>
	
	<div class="clase_ligas">
		<a href="jsp/reportesEspeciales/enjambreGolfoCalifornia29mar2016.pdf">Sismos del 25 al 28 de Marzo de 2016, Golfo de California.</a><br><br>
		<a href="jsp/reportesEspeciales/SismoJalisco21Ene2016.pdf">Sismo del d&iacute;a 21 de Enero de 2016, Jalisco (M 6.5)</a><br><br>
		<a href="jsp/reportesEspeciales/SismosJalisco2015-1.pdf">Sismos de diciembre de 2015, regi&oacute;n norte Jalisco</a><br><br>
		<a href="jsp/reportesEspeciales/sismoMayor.pdf">Zona de subducci&oacute;n mexicana y su potencial para un sismo mayor</a><br><br>
		<a href="jsp/reportesEspeciales/Magnitud-de-un-sismo.pdf">C&aacute;lculo de Magnitud</a><br><br>
		<!--<a href="http://usuarios.geofisica.unam.mx/cruz/Forros-Indice-Introduccion-Opt.pdf" target="_blank">Libro: &quot;Los sismos. Una Amenaza Cotidiana&quot;</a><br><br>-->
	</div>
	
	<div class="contacto">
	   <a href="mailto:webmaster@sismologico.unam.mx"><img src="img/arrobami.jpg" border="0">&nbsp;&nbsp;Comentarios y Sugerencias</a>&nbsp;&nbsp;&nbsp;&nbsp;
	   <a href="http://www2.ssn.unam.mx/website/jsp/sismotel.jsp"><img src="img/telmi.gif" border="0">&nbsp;&nbsp;Sismotel</a>&nbsp;&nbsp;&nbsp;&nbsp;
	   <a href="http://facebook.com/sismologicomx"><img src="img/facebookmini.jpg" border="0"></a>&nbsp;&nbsp;y&nbsp;
	   <a href="http://twitter.com/sismologicoMX"><img src="img/twittermi.jpg" border="0">&nbsp;&nbsp;Reportes de sismicidad</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://twitter.com/SSN_mx"><img src="img/twittermi.jpg" border="0">&nbsp;&nbsp;Preguntas y comentarios</a>&nbsp;&nbsp;&nbsp;&nbsp;
	   <!--<a href="http://www2.ssn.unam.mx/html/SSN/reporta-sismo.jsp">&iquest;Sinti&oacute; un sismo?</a>-->
	   <a onclick="rediruanlsismo()" href="http://eventos.uanl.mx/sismologia" target="_blank">&iquest;Sinti&oacute; un sismo?</a>
        </div>
        
        <div id="piePag">
	   Hecho en M&eacute;xico, Universidad Nacional Aut&oacute;noma de M&eacute;xico, (UNAM), todos los derechos reservados 2011. Esta p&aacute;gina puede ser reproducida con fines no lucrativos, siempre y cuando no se mutile, se cite la fuente completa y su direcci&oacute;n electr&oacute;nica. De otra forma requiere permiso previo por escrito de la instituci&oacute;n.
Servicio Sismol&oacute;gico Nacional, Instituto de Geof&iacute;sica, UNAM. Circuito de la investigaci&oacute;n Cient&iacute;fica s/n, Ciudad Universitaria, Delegaci&oacute;n Coyoac&aacute;n, C.P. 04510, M&eacute;xico D.F.
Sitio web administrado por: Servicio Sismol&oacute;gico Nacional, webmaster@sismologico.unam.mx 
	</div>	
        
</div>

		<script type="text/javascript">
			function rediruanlsismo() {
				alert('AVISO: A continuacion seras redirigido a un pagina externa al SSN para acceder a la encuesta \"Sintio un sismo\" de la Facultad de Ciencias de la Tierra de Universidad Autonoma de Nuevo Leon (UANL). (Texto preformateado sin acentos).');
			}
		</script>


</body>
</html>
