<head>

</head>
<?php
include 'cnx.php';
error_reporting(0);
$con=mysql_query("select * from temblor1");
$r=mysql_fetch_array($con);
$luga=$r['lugar'];
echo $luga;

$result=mysql_query("select * from destinos")or die(mysql_error());
while($row=mysql_fetch_array($result)){
	$correo=$row['correo'];
	echo $correo;
	
	echo $luga;
	
	echo "-";
	
	echo "<script>";
	echo "window.open('/correo/correo.php?correo=$correo', '_new')";
echo "</script>";


}

?>