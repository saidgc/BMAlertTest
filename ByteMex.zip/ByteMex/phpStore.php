<?php
	$host='127.0.0.1';
	$user='u509644246_tt';
	$password='12345678';
	
	$connection = mysql_connect($host,$user,$password);
	
	$usernmae = $_POST['a'];
	$pass = $_POST['b'];
	$info = $_POST['c'];
	$num = $_POST['d'];
	
	if(!$connection){
		die('Connection Failed');
	}
	else{
		$dbconnect = @mysql_select_db('u509644246_tembl', $connection);
		
		if(!$dbconnect){
			die('Could not connect to Database');
		}
		else{
			$query = "INSERT INTO `destinos`.`Users` (`id`, `correo`, `nombre`)
				VALUES (null,'$username','$info');";
			mysql_query($query, $connection) or die(mysql_error());
			
			echo 'Successfully added.';
			echo $query;
		}
	}
?>