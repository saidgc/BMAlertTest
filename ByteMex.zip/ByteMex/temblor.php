<?php
error_reporting(0);
include 'cnx.php';
date_default_timezone_set('UTC');
date_default_timezone_set("America/Mexico_City");
$fecha= $_GET['t'];
$lugar= $_GET['l'];
$d = date("m");
$m = date("d");
$y = date("y");
$fe='20'.$y.'-'.$d.'-'.$m;
if ($_GET['t']=='20'.$y.'-'.$d.'-'.$m){
	$cons=mysql_query("select * from temblor1 where fecha='$fe'");
	if (mysql_num_rows($cons)>0){
//echo "select * from temblor1 where='$fe'";

	}else{
		
		//echo "select * from temblor1 where='$fe'";
		mysql_query("insert into temblor1 values(null,'$fecha','$lugar')")or die("Error");
		
		header('location:/enviacorreo.php?en=1');
		echo 'insertado';

		}
	}else{
	echo $_GET['t'];
echo "-";
	echo $fe;

}



?>