 
<?php

class Conn {
public static $dbhost = "127.0.0.1";
public static $dbuser = "u509644246_tt";
public static $dbpass = "12345678";
public static $dbname = "u509644246_tembl";
}

?>